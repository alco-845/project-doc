package com.example.storyapp.helper

object PrefData {
    var token: String = ""
}